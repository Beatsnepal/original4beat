"use client";

export default function AdminMainPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Admin Panel</h1>
      <p>Welcome to the main admin page.</p>
    </div>
  );
}
